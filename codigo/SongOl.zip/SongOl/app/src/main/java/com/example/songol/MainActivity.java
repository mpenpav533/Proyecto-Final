package com.example.songol;

import static java.util.Objects.*;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.songol.databinding.ActivityMainBinding;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Objects;

public class MainActivity extends AppCompatActivity  {

    public ActivityMainBinding binding;// Vincular la vista con la actividad
    public SharedPreferences bbdd;//Para obtener la informacion del hilo

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //establece la vinculacion
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        this.bbdd = this.getSharedPreferences("bbdd", Context.MODE_PRIVATE);

        binding.btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseDatos.login(MainActivity.this, binding.username.getText().toString(), new Runnable() {
                    @Override
                    public void run() {
                        //success
                        String username = bbdd.getString("result","");
                        try {
                            JSONObject u = new JSONObject(username);
                            Usuario usuario = new Usuario().converJson(u);
                            Snackbar.make(binding.layout,"Hola que ase "+ usuario.getUsername(),Snackbar.LENGTH_LONG).show();
                        } catch (JSONException e) {

                            Toast.makeText(MainActivity.this, "Error al extraer el usuario.", Toast.LENGTH_LONG).show();

                        }


                    }
                }, new Runnable() {
                    @Override
                    public void run() {
                        //error
                        String username = bbdd.getString("result","");
                        Toast.makeText(MainActivity.this, username, Toast.LENGTH_LONG).show();
                    }
                });

            }
        });
        binding.btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseDatos.insert(MainActivity.this, "holo", new Runnable() {
                            @Override
                            public void run() {
                                //success
                                String username = bbdd.getString("result","");

                                    //JSONObject u = new JSONObject(username);
                                   //Usuario usuario = new Usuario().converJson(u);
                                    Snackbar.make(binding.layout,"bienvenido"+ username,Snackbar.LENGTH_LONG).show();

                            }
                        },
                        new Runnable() {
                            @Override
                            public void run() {
                                String username = bbdd.getString("result","");
                                Toast.makeText(MainActivity.this, username, Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });
    }

}