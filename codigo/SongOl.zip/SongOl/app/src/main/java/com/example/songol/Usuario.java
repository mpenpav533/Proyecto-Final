package com.example.songol;

import org.json.JSONException;
import org.json.JSONObject;

public class Usuario {
    private int id;
    private String username;
    private int puntos;
    private int pJugadas;
    private int pGanadas;
    private int pPerdidas;

    public Usuario() {
    }

    public Usuario usuarioInsert(String username) {

        this.username = username;
        this.puntos = 0;
        this.pJugadas = 0;
        this.pGanadas = 0;
        this.pPerdidas = 0;
        return this;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public int getpJugadas() {
        return pJugadas;
    }

    public void setpJugadas(int pJugadas) {
        this.pJugadas = pJugadas;
    }

    public int getpGanadas() {
        return pGanadas;
    }

    public void setpGanadas(int pGanadas) {
        this.pGanadas = pGanadas;
    }

    public int getpPerdidas() {
        return pPerdidas;
    }

    public void setpPerdidas(int pPerdidas) {
        this.pPerdidas = pPerdidas;
    }

    public Usuario converJson(JSONObject jsonObject) throws JSONException {

        this.setId(jsonObject.getInt("id_usuario"));
        this.setUsername(jsonObject.getString("username"));
        this.setPuntos(jsonObject.getInt("puntos"));
        this.setpJugadas(jsonObject.getInt("pJugadas"));
        this.setpGanadas(jsonObject.getInt("pGanadas"));
        this.setpPerdidas(jsonObject.getInt("pPerdidas"));

        return this;
    }
}
